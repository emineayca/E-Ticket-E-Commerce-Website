﻿using System;
using System.Collections;
using System.Linq.Expressions;

namespace eTickets_Web.wwwroot.Base
{
    public interface IEntityBaseRepository< T> where T : class,IEntityBase,new()
    {
        //ortak metotlar yazıyoruz
        IEnumerable<T> GetAll();// tüm kayıtları listeleme ,çıkış tipi T ve bir liste yapısında (ENumerable)

        IEnumerable<T> GetAll(params Expression<Func<T, object>>[] includeProperties);// tüm kayıtları listeleme,ana parametreli yapı

        // sadece tek bir kayıt getirmek istediğimizde 
        T GetById(int id);

        // kayıt ekleme 
        void Add(T entity);

        //kayıt güncelleme 

        void Update(int id, T entity); // güncellemede id lazım 

        void Delete(int id);   // ilgili modelden bunu çağıracagım için t yapısı kullanmadık




    }
}
