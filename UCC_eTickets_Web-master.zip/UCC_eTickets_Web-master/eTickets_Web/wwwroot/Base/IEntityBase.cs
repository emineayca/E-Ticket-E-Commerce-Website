﻿namespace eTickets_Web.wwwroot.Base
{
    public interface IEntityBasee
    {
        // modellere taban teskil edecek 

    }
}
