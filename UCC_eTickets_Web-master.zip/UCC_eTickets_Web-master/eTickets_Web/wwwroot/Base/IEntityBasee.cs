﻿

using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace eTickets_Web.wwwroot.Base
{
    public class Actor:IEntityBase
    {

        [Key]
        public int Id { get; set; }

        [Display(Name = "Profile Picture ")] // viewlerdeki ilgili alanın dışındaki görünecek text

        [Required(ErrorMessage = " Profile Picture alanı adı gereklidir ...")]


        public string ProfilePictureURL { get; set; }


        [Display(Name = "Full Name")] // viewlerdeki ilgili alanın dışındaki görünecek text

        [Required(ErrorMessage = "Tam alan adı gereklidir ")]

        [StringLenght(50,MinimumLenght=3,ErrorMessage="Ad Bilgisi 3-50 karakter arasında olmalıdır ...")]


        public string FullName { get; set; }

        [Display(Name = "bıograpy")] // viewlerdeki ilgili alanın dışındaki görünecek text

        [Required(ErrorMessage = "bıograpy alan adı gereklidir ")]


        public string Bio { get; set; }



    }
}
