﻿
using Microsoft.EntityFrameworkCore;

namespace eTickets_Web.Models.Data
{

    public class AppDbContext : IdentityDbContext<ApplicationUser>
    {
        //Models=>

        // Constructor
            public AppDbContext(DbContextOptions<AppDbContext>options):base(options)
        { 
        
        
        
        }

        //tablolar arası ilişkilerin belirtilmesi
        //temel sınıftaki metodun yerine kendi yazdığımızın çalışmasını sağlamış oluyoruz..

        protected override void OnModeCreating(ModelBuilder modelBuilder)
        {

            //Actor_Movie<=>movie relation
            // İlişkiler//HASKEY anahtarları tutuyor veritabınındaki
            modelBuilder.Entity<Actor_Movies>().HasKey(acmo=>new ){
                acmo.ActorId,acmo.MovieId
                    )};
            //Actor_Movie<=>Actor relation 
            modelBuilder.Entity<Actor_Movie>()
                .HasOne(m=>m.Actor)
                .WithMany(acmo=>acmo.Actor_Movies)
                .HasForeignKey(m=>m.ActorId)

                base.Equals(modelBuilder);  


        }

        }
    }
}
