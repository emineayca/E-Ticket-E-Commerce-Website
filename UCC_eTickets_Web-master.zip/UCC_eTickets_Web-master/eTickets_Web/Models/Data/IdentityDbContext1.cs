﻿namespace eTickets_Web.Models.Data
{
    public class IdentityDbContext<T>
    {
    }
}