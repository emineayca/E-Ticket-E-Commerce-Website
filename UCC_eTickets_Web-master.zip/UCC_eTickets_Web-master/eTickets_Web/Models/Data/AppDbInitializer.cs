﻿namespace eTickets_Web.Models.Data
{

    //burası vı yaratılırken Dummy veriyle yaratılması için 

    //servis yapısı kullanılacak 
    public class AppDbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {
            //kapsam belirleniyor
            using (var serviceScope=applicationBuilder.ApplicationServices.CreateScope()); 
            {
                var context =AsyncServiceScope.ServiceProvider.GetService<AppDbContext>();//AppDbContext imi bir servis olarak alıyorum 

                // Db var mı / yok mu 
                context.Database.EnsureCreated();// vt var mı yok mu ensure anlıyor 

                //cinema table için dummy data 

                if (!context.Cinemas.Any())// tablonun içinde herhangi bir kayıt var mı yok mu 
                {
                    // kayıt yok.. gel buraya 

                    context.Cinemas.AddRange(new List<Cinema>()
                    {

                        // örnek data kısmı 
                         new Cinema () {
                         
                         Name= " Cinema1",

                         Logo="http :// "

                         Description="This is Cinemal"


                         
                         }
                    });




                }


            }
        }


    }
}
