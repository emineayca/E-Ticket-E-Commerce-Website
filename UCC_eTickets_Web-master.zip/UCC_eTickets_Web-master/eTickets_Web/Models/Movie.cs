﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eTickets_Web.Models
{
    public class Movie : IEntityBase

    {
        [Key]

        public int Id { get; set; }

        [Display()


            // one to many - cinema 
        public int CinemaId { get; set; }
        [ForeignKey("CinemaId")]

        // one to many -producer
        public Cinema Cinema { get; set; }


         
    }
}
