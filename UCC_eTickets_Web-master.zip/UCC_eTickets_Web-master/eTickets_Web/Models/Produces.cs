﻿namespace eTickets_Web.Models
{
    public class Produces:IEntityBase
    {
        [Key]

        public string Id { get; set; }

        public List<Movie> Movies { get; set; }// bir producerın birden fazla filmi olabilir 
    }
}
