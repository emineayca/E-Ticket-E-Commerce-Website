﻿namespace eTickets_Web.Models
{
    //Actor bilgilerini tutacak class
    public class Actor
    {

        .. yaz burayı 

            //ilişki oldu juction ile
            public List<Actor_Movies> Actor_Movies { get; set; }
            
    }
    
}
