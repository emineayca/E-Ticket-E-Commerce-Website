﻿using System.ComponentModel.DataAnnotations;

namespace eTickets_Web.Models
{
    public class Cinema: IEntityBase

    {
        [Key]
        public int Id { get; set; }

       
       
       
        public string Logo { get; set; }


         [Display(Name = "cinema  Logo ")] // viewlerdeki ilgili alanın dışındaki görünecek text

        [Required(ErrorMessage = "Tam cinema alan adı gereklidir ")]

        [StringLenght(50, MinimumLenght = 3, ErrorMessage = " cinema Ad Bilgisi 3-50 karakter arasında olmalıdır ...")]


        public string Name { get; set; }// cinema 

        [Display(Name = "Cinema Name")] // viewlerdeki ilgili alanın dışındaki görünecek text

        


        public string Description { get; set; }
        [Display(Name = " Description bıograpy")] // viewlerdeki ilgili alanın dışındaki görünecek text

        public List<Movie> Movies { get; set; }
    }
}
