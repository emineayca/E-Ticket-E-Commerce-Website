﻿using System.ComponentModel;

namespace eTickets_Web.Models
{
    public class ApplicationUser : IdentityUser
    {
        [DisplayName(Name="FullName")]
        public string FullName { get; set; }

    }
}
