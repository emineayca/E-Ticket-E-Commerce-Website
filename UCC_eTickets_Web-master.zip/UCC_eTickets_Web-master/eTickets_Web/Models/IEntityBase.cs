﻿namespace eTickets_Web.Models
{
    public interface IEntityBase
    {
    }
}