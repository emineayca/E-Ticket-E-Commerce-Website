﻿namespace eTickets_Web.Models
{
    public class IdentityUser
    {
    }
}