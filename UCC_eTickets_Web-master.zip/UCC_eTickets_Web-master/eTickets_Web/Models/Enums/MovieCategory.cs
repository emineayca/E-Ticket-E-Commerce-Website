﻿namespace eTickets_Web.Models.Enums
{
    public enum  MovieCategory
    {
        // enum sabit değer demek 
        //Movie Kategorileri listesi enum yapısı şeklinde tutulacak 

        // normalde enum yapısı index değerini 0 dan tutar .. ama ben 1 den başlamasını istiyorum ki ilişkilendirmelere girecek 

        Action=1,// kod gibi yazdık öyle algılıycak 

        Comedy,

        Drama,

        Documentary,

        Cartoon,

        Horror,



    }
}
